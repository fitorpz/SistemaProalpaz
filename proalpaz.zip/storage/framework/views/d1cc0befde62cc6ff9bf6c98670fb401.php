

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h4 class="text-left fw-bold text-secondary mb-4">
        <i class="fas fa-arrow-circle-up me-2"></i>Bajas de Inventario
    </h4>

    <a href="<?php echo e(route('inventario.index')); ?>" class="btn btn-primary">Atrás</a>

    <!-- Formulario de búsqueda -->
    <form action="<?php echo e(route('bajas.buscar')); ?>" method="GET" class="d-flex mb-4">
        <input type="text" name="query" class="form-control" placeholder="Buscar por código, nombre o fecha">
        <button type="submit" class="btn btn-primary ms-2">Buscar</button>
    </form>

    <!-- Resultados de la búsqueda -->
    <?php if($resultados->isNotEmpty()): ?>
    <h4 class="mb-3">Resultados de Búsqueda</h4>
    <div class="table-responsive mb-5">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Código Producto</th>
                    <th>Nombre Producto</th>
                    <th>Cantidad</th>
                    <th>Almacén</th>
                    <th>Fecha Registro</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->id); ?></td>
                    <td><?php echo e($producto->codigo_producto); ?></td>
                    <td><?php echo e($producto->nombre_producto); ?></td>
                    <td><?php echo e($producto->cantidad); ?></td>
                    <td><?php echo e($producto->almacen); ?></td>
                    <td><?php echo e($producto->fecha_registro); ?></td>
                    <td>
                        <!-- Botón de acción para registrar baja -->
                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#bajaModal" data-id="<?php echo e($producto->id); ?>" data-codigo="<?php echo e($producto->codigo_producto); ?>" data-nombre="<?php echo e($producto->nombre_producto); ?>" data-cantidad="<?php echo e($producto->cantidad); ?>" data-almacen="<?php echo e($producto->almacen); ?>">
                            Registrar Baja
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="alert alert-info text-center mb-5">No se encontraron resultados de búsqueda.</div>
    <?php endif; ?>

    <!-- Tabla de bajas realizadas -->
    <h4 class="mb-3">Bajas Realizadas</h4>
    <?php if($bajas->isNotEmpty()): ?>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Código Producto</th>
                    <th>Nombre Producto</th>
                    <th>Cantidad</th>
                    <th>Almacén</th>
                    <th>Motivo</th>
                    <th>Fecha Baja</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($baja->id); ?></td>
                    <td><?php echo e($baja->codigo_producto); ?></td>
                    <td><?php echo e($baja->nombre_producto); ?></td>
                    <td><?php echo e($baja->cantidad); ?></td>
                    <td><?php echo e($baja->almacen); ?></td>
                    <td><?php echo e($baja->motivo); ?></td>
                    <td><?php echo e($baja->fecha_registro); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="alert alert-info text-center">No hay bajas registradas.</div>
    <?php endif; ?>
</div>

<!-- Modal para registrar bajas -->
<div class="modal fade" id="bajaModal" tabindex="-1" aria-labelledby="bajaModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('bajas.registrar')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="bajaModalLabel">Registrar Baja</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="producto-id">
                    <div class="mb-3">
                        <label for="codigo-producto" class="form-label">Código Producto</label>
                        <input type="text" class="form-control" id="codigo-producto" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="nombre-producto" class="form-label">Nombre Producto</label>
                        <input type="text" class="form-control" id="nombre-producto" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="cantidad" class="form-label">Cantidad a Dar de Baja</label>
                        <input type="number" class="form-control" name="cantidad" id="cantidad" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label for="motivo" class="form-label">Motivo</label>
                        <textarea class="form-control" name="motivo" id="motivo" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="almacen" class="form-label">Almacén</label>
                        <input type="text" name="almacen" id="almacen" class="form-control" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-danger">Registrar Baja</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const bajaModal = document.getElementById('bajaModal');
        bajaModal.addEventListener('show.bs.modal', (event) => {
            const button = event.relatedTarget;
            const id = button.getAttribute('data-id');
            const codigo = button.getAttribute('data-codigo');
            const nombre = button.getAttribute('data-nombre');
            const almacen = button.getAttribute('data-almacen');

            bajaModal.querySelector('#producto-id').value = id;
            bajaModal.querySelector('#codigo-producto').value = codigo;
            bajaModal.querySelector('#nombre-producto').value = nombre;
            bajaModal.querySelector('#almacen').value = almacen;
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proalpaz3\resources\views/bajas/index.blade.php ENDPATH**/ ?>