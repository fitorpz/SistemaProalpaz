<?php

use Carbon\Carbon;
// 📌 Fecha y hora actual de generación del PDF
$fechaGeneracion = Carbon::now()->format('d/m/Y');
function numberToWords($number)
{
    if (!class_exists('NumberFormatter')) {
        return 'La extensión intl no está habilitada en el servidor.';
    }

    $parts = explode('.', number_format($number, 2, '.', ''));
    $whole = $parts[0];
    $fraction = $parts[1] ?? '00';

    $formatter = new \NumberFormatter('es', \NumberFormatter::SPELLOUT);
    $literal = $formatter->format($whole);

    return ucfirst($literal) . ' con ' . $fraction . '/100';
}
// Obtener el almacén de la preventa
$almacenId = $preventa->cliente->almacen_id ?? ($preventa->detalles->first()->producto->almacen_id ?? null);

$almacenLogos = [
    1 => public_path('logoHeader.png'),
    4 => public_path('logoVDN.png'),
];
// Determinar el logo según el almacén (si no hay coincidencia, usa 'logoHeader.png')
$logoPath = $almacenLogos[$almacenId] ?? public_path('logoHeader.png');
?>

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota de Remisión</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
        }

        .header,
        .footer {
            text-align: center;
            margin-bottom: 20px;
        }

        .header img {
            max-width: 150px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .table th,
        .table td {
            border: 1px solid #000;
            padding: 5px;
            text-align: left;
        }

        .table th {
            background-color: #f2f2f2;
        }

        .align-left {
            text-align: left;
        }

        .align-right {
            text-align: right;
        }

        .row {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>

<body>
    <div class="container">
        
        <div class="header">
            <div class="header">
                <!-- Encabezado con Logo y Datos de la Empresa -->
                <table style="width: 100%; margin-bottom: 20px; border: none;">
                    <tr>
                        <td style="width: 50%; text-align: left; vertical-align: middle; border: none;">
                            <img src="<?php echo e($logoPath); ?>" alt="Logo de la empresa" style="width: 180px; height: auto;">
                            <p style="margin: 0; font-size: 12px; font-weight: bold;">NIT: 123123123</p>
                            <p style="margin: 0; font-size: 12px; font-weight: bold;">Calle Juan Manuel Carpio N° 275</p>
                            <p style="margin: 0; font-size: 12px;">Zona Los Andes El Alto</p>
                            <p style="margin: 0; font-size: 12px;">Cel.: 77246463 - 65178769</p>
                            
                        </td>
                    </tr>
                </table>
            </div>
            <h3>Nota de Remisión</h3>
            <p><strong>Fecha de entrega:</strong> <?php echo e($fechaGeneracion); ?></p>
        </div>

        
        <table class="table">
            <tr>
                <th>Cliente</th>
                <td><?php echo e($preventa->cliente->nombre_comercio); ?></td>
                <th>Fecha Preventa</th>
                <td><?php echo e($preventa->created_at->format('d/m/Y')); ?></td>
            </tr>
            <tr>
                <th>Vendedor</th>
                <td><?php echo e($preventa->preventista->nombre ?? 'No especificado'); ?></td>
                <th>Código Preventa</th>
                <td><?php echo e($preventa->numero_pedido); ?></td>
            </tr>
            <tr>
                <th>Modalidad de Pago</th>
                <td><?php echo e($modalidadPago); ?></td> <!-- ✅ Agregado -->
                <th>Observaciones</th>
                <td><?php echo e($preventa->observaciones ?? 'Sin observaciones'); ?></td>
            </tr>
        </table>
        
        <table class="table">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Producto</th>
                    <th>Lote</th>
                    <th>Fecha de vencimiento</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detalle['codigo']); ?></td>
                    <td><?php echo e($detalle['producto']); ?></td>
                    <td><?php echo e($detalle['lote']); ?></td>
                    <td><?php echo e($detalle['fecha_vencimiento']); ?></td>
                    <td><?php echo e($detalle['cantidad']); ?></td>
                    <td><?php echo e($detalle['precio_unitario']); ?></td>
                    <td><?php echo e($detalle['subtotal']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="total-row">
                    <td colspan="6">TOTAL Bs.: <?php echo e(numberToWords($preventa->detalles->sum('subtotal'))); ?> </td>
                    <td><?php echo e(number_format($preventa->detalles->sum('subtotal'), 2)); ?></td>
                </tr>
            </tbody>
        </table><br>
        <?php if($preventa->descuento > 0): ?>
        
        <table class="table">
            <tr>
                <th>Subtotal Bs.</th>
                <td><?php echo e(number_format($preventa->detalles->sum('subtotal'), 2)); ?></td>
            </tr>


            <tr>
                <th>Descuento Aplicado (<?php echo e($preventa->descuento); ?>%)</th>
                <td>- <?php echo e(number_format(($preventa->detalles->sum('subtotal') * $preventa->descuento) / 100, 2)); ?></td>
            </tr>


            <tr class="total-row">
                <th>TOTAL FINAL Bs.</th>
                <td><strong><?php echo e(number_format($preventa->precio_total, 2)); ?></strong></td>
            </tr>
            <tr>
                <th>Total en Letras</th>
                <td><?php echo e(numberToWords($preventa->precio_total)); ?></td>
            </tr>
        </table>
        <?php endif; ?>
        
        <div class="row" style="display: flex; justify-content: space-between; margin-top: 50px;">
            <!-- Columna izquierda -->
            <div class="col-md-6" style="width: 45%; text-align: center; margin-left: 50px">
                <p style="margin-bottom: 5px;">________________________</p>
                <p>Entregué Conforme</p>
            </div>
            <!-- Columna derecha -->
            <div class="col-md-6" style="width: 45%; text-align: center; margin-top: -80px; margin-left: 300px">
                <p style="margin-bottom: 5px;">________________________</p>
                <p>Recibí Conforme</p>
            </div>
        </div>

    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\proalpaz3\resources\views/preventas/nota-remision.blade.php ENDPATH**/ ?>