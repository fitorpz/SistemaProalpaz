

<?php $__env->startSection('content'); ?>
<style>
    .table-responsive {
        max-height: 400px;
        overflow-y: auto;
        border: 1px solid #ccc;
    }

    .table thead tr {
        position: sticky;
        top: 0;
        background: #fff;
        z-index: 100;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }
</style>
<div class="container">
    <h4 class="text-left fw-bold text-secondary mb-4">
        <i class="fas fa-address-book me-2"></i>Cuentas por Cobrar Externas
    </h4>

    <div class="d-flex justify-content-end mb-3">
        <h4 class="fw-bold">
            Total por cobrar: <span id="total-generado"><?php echo e(number_format($cuentas->sum('monto_total'), 2)); ?></span> Bs.
        </h4>
    </div>

    <!-- 📌 Filtros -->
    <form method="GET" action="<?php echo e(route('contabilidad.cobranzas.externas.index')); ?>" class="mb-3">
        <div class="row g-2 align-items-end">
            <!-- Filtro por nombre o categoría -->
            <div class="col-12 col-md-4">
                <label for="filtro_nombre" class="form-label fw-bold">Buscar por Nombre o Categoría</label>
                <input type="text" name="filtro_nombre" id="filtro_nombre" class="form-control" placeholder="Ej: FARMACIAS..." value="<?php echo e(request('filtro_nombre')); ?>">
            </div>

            <!-- Filtro por Estado -->
            <div class="col-12 col-md-2">
                <label for="estado" class="form-label fw-bold">Estado</label>
                <select name="estado" id="estado" class="form-select">
                    <option value="">Todos</option>
                    <option value="Activo" <?php echo e(request('estado') == 'Activo' ? 'selected' : ''); ?>>Activo</option>
                    <option value="Inactivo" <?php echo e(request('estado') == 'Inactivo' ? 'selected' : ''); ?>>Inactivo</option>
                </select>
            </div>

            <!-- Botones de Acción -->
            <div class="col-12 col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter"></i> Filtrar
                </button>
                <a href="<?php echo e(route('contabilidad.cobranzas.externas.index')); ?>" class="btn btn-secondary w-100">
                    <i class="fas fa-sync-alt"></i> Restablecer
                </a>
            </div>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Concepto</th>
                    <th>Monto Total (Bs)</th>
                    <th>Vencimiento</th>
                    <th>Estado</th>
                    <th>Observaciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($cuenta->nombre); ?></td>
                    <td><?php echo e($cuenta->categoria ?? '-'); ?></td>
                    <td><?php echo e($cuenta->concepto); ?></td>
                    <td><?php echo e(number_format($cuenta->monto_total, 2)); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($cuenta->fecha_vencimiento)->format('d/m/Y')); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($cuenta->estado == 'Activo' ? 'success' : 'secondary'); ?>">
                            <?php echo e($cuenta->estado); ?>

                        </span>
                    </td>
                    <td><?php echo e($cuenta->observaciones ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('contabilidad.cobranzas.externas.historial', $cuenta->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-history"></i> Ver Historial
                        </a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">No hay registros que coincidan.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proalpaz3\resources\views/contabilidad/cobranzas/externas_index.blade.php ENDPATH**/ ?>