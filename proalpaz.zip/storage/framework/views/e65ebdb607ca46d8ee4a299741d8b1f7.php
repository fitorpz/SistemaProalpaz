


<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="text-left fw-bold text-secondary mb-4">
        <i class="fas fa-user-plus me-2"></i>Registrar Cliente
    </h4>

    <form action="<?php echo e(route('clientes.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('clientes.partials.form', ['formType' => 'create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="d-flex justify-content-between mt-4">
            <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Guardar Cliente
            </button>
        </div>
    </form>
</div>

<script>
    function setLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    const latitude = position.coords.latitude;
                    const longitude = position.coords.longitude;
                    document.getElementById("ubicacion").value = `https://www.google.com/maps?q=${latitude},${longitude}`;
                },
                function(error) {
                    alert('Error al obtener la ubicación.');
                }
            );
        } else {
            alert('Tu navegador no admite geolocalización.');
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proalpaz_limpio\resources\views/clientes/crear.blade.php ENDPATH**/ ?>