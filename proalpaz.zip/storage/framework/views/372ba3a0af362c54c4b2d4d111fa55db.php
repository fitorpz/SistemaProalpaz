

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="text-secondary fw-semibold mb-3">
        <i class="fas fa-warehouse me-2 text-primary"></i>Productos Asignados
    </h4>

    <?php if(session('warning')): ?>
    <div class="alert alert-warning"><?php echo e(session('warning')); ?></div>
    <?php endif; ?>

    <?php if($ingresos->isEmpty()): ?>
    <div class="alert alert-warning">No tienes productos asignados a tus almacenes.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-success">
                <tr>
                    <th>Código Producto</th>
                    <th>Nombre Producto</th>
                    <th>Cantidad Total</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ingresos->groupBy('codigo_producto'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigoProducto => $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Fila principal -->
                <tr class="table-primary" data-bs-toggle="collapse" data-bs-target="#details-<?php echo e($codigoProducto); ?>" aria-expanded="false" aria-controls="details-<?php echo e($codigoProducto); ?>">
                    <td><?php echo e($codigoProducto); ?></td>
                    <td><?php echo e($productos->first()->nombre_producto); ?></td>
                    <td><?php echo e($productos->sum('cantidad')); ?></td>
                    <td>
                        <button class="btn btn-info btn-sm">Ver Detalles</button>
                    </td>
                </tr>
                <!-- Fila desplegable -->
                <tr class="collapse" id="details-<?php echo e($codigoProducto); ?>">
                    <td colspan="4">
                        <table class="table table-sm table-bordered" style="font-size: 16px; text-align: center;">
                            <thead>
                                <tr>
                                    <th>Lote</th>
                                    <th>Fecha de Vencimiento</th>
                                    <th>Cantidad</th>
                                    <th>Almacén</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($producto->lote); ?></td>
                                    <td><?php echo e($producto->fecha_vencimiento ?? 'Sin Fecha'); ?></td>
                                    <td><?php echo e($producto->cantidad); ?></td>
                                    <td><?php echo e($producto->almacen->nombre ?? 'No especificado'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proalpaz3\resources\views/ingresos/asignados.blade.php ENDPATH**/ ?>