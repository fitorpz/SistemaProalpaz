

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center">Panel de Reportes</h2>
    <p class="text-center">Genera y descarga reportes en PDF de cada módulo.</p>

    <div class="row mt-4">
        <!-- Reporte de Ventas -->
        <div class="col-md-6 col-lg-3 mb-4 d-flex">
            <div class="card text-center shadow-sm flex-fill">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-cash-register me-2"></i> Reporte de Ventas
                </div>
                <div class="card-body">
                    <p>Consulta y genera reportes de las ventas realizadas.</p>
                    <a href="<?php echo e(route('reportes.ventas')); ?>" class="btn btn-danger">Ir a Reporte</a>
                </div>
            </div>
        </div>

        <!-- Reporte de Preventas -->
        <div class="col-md-6 col-lg-3 mb-4 d-flex">
            <div class="card text-center shadow-sm flex-fill">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-users me-2"></i> Reporte de Clientes
                </div>
                <div class="card-body">
                    <p>Descarga un reporte de todas las Clientes registrados.</p>
                    <a href="<?php echo e(route('reportes.clientes')); ?>" class="btn btn-success">Ir a Reporte</a>
                </div>
            </div>
        </div>

        <!-- Reporte de Inventario -->
        <div class="col-md-6 col-lg-3 mb-4 d-flex">
            <div class="card text-center shadow-sm flex-fill">
                <div class="card-header bg-info text-white">
                    <i class="fas fa-dolly me-2"></i> Reporte de Rutas
                </div>
                <div class="card-body">
                    <p>Consulta el estado actual de las Rutas</p>
                    <a href="<?php echo e(route('reportes.rutas')); ?>" class="btn btn-info">Ir a reporte</a>
                </div>
            </div>
        </div>

        <!-- Reporte de Picking & Packing -->
        <div class="col-md-6 col-lg-3 mb-4 d-flex">
            <div class="card text-center shadow-sm flex-fill">
                <div class="card-header bg-warning text-white">
                    <i class="fas fa-shopping-cart me-2"></i> Reporte de Preventas
                </div>
                <div class="card-body">
                    <p>Obtén un reporte de las Preventas</p>
                    <a href="<?php echo e(route('reportes.preventas')); ?>" class="btn btn-warning">Ir a reporte</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proalpaz_limpio\resources\views/reportes/index.blade.php ENDPATH**/ ?>