

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center">Reporte de Clientes</h2>
    <form method="GET" action="<?php echo e(route('reportes.clientes')); ?>" class="mb-4">
        <div class="row">
            <div class="col-md-4">
                <input type="text" name="nombre" class="form-control" placeholder="Buscar por Nombre..." value="<?php echo e(request('nombre')); ?>">
            </div>
            <div class="col-md-3">
                <input type="text" name="codigo_cliente" class="form-control" placeholder="Código de Cliente..." value="<?php echo e(request('codigo_cliente')); ?>">
            </div>
            <div class="col-md-3">
                <input type="text" name="nit" class="form-control" placeholder="NIT..." value="<?php echo e(request('nit')); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Filtrar</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Comercio</th>
                <th>NIT</th>
                <th>Teléfono</th>
                <th>Dirección</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cliente->id); ?></td>
                <td><?php echo e($cliente->codigo_cliente); ?></td>
                <td><?php echo e($cliente->nombre_propietario); ?></td>
                <td><?php echo e($cliente->nombre_comercio); ?></td>
                <td><?php echo e($cliente->nit ?? 'N/A'); ?></td>
                <td><?php echo e($cliente->telefono ?? 'N/A'); ?></td>
                <td><?php echo e($cliente->direccion ?? 'N/A'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <a href="<?php echo e(route('reportes.clientes.pdf', request()->all())); ?>" class="btn btn-danger">Generar PDF</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proalpaz3\resources\views/reportes/clientes.blade.php ENDPATH**/ ?>