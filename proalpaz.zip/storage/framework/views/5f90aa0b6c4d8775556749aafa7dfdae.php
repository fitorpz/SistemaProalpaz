

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h3 class="text-center mb-4">REPORTE DE VENTAS</h3>

    <!-- Filtros -->
    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-4">
            <label for="usuario_id" class="form-label">Preventista</label>
            <select name="usuario_id" id="usuario_id" class="form-select">
                <option value="">-- Todos --</option>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($usuario->id); ?>" <?php echo e(request('usuario_id') == $usuario->id ? 'selected' : ''); ?>>
                    <?php echo e($usuario->nombre); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="del" class="form-label">Desde</label>
            <input type="date" name="del" id="del" class="form-control" value="<?php echo e(request('del')); ?>">
        </div>
        <div class="col-md-3">
            <label for="al" class="form-label">Hasta</label>
            <input type="date" name="al" id="al" class="form-control" value="<?php echo e(request('al')); ?>">
        </div>
        <div class="col-md-1 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">Filtrar</button>
        </div>
        <div class="col-md-1 d-flex align-items-end">
            <a href="<?php echo e(route('reportes.ventas')); ?>" class="btn btn-secondary w-100">Restablecer</a>
        </div>
    </form>


    <div class="col-md-12 text-end mb-3">
        <a target="_blank" href="<?php echo e(route('reportes.ventas.pdf', request()->query())); ?>" class="btn btn-danger">
            <i class="fas fa-file-pdf"></i> Descargar PDF
        </a>
    </div>

    <!-- Resumen -->
    <div class="mb-3 d-flex justify-content-between">
        <div>
            <strong>PREVENTISTA:</strong>
            <?php echo e($usuarios->firstWhere('id', request('usuario_id'))->nombre ?? 'Todos'); ?><br>
            <strong>DEL:</strong> <?php echo e(request('del') ?? '---'); ?><br>
            <strong>AL:</strong> <?php echo e(request('al') ?? '---'); ?>

        </div>
        <div>
            <strong>TOTAL VENTAS CRÉDITO:</strong> Bs. <?php echo e(number_format($totalCredito, 2, ',', '.')); ?><br>
            <strong>TOTAL VENTAS CONTADO:</strong> Bs. <?php echo e(number_format($totalContado, 2, ',', '.')); ?><br>
            <strong>TOTAL VENTAS PROMOCIÓN:</strong> Bs. <?php echo e(number_format($totalPromocion, 2, ',', '.')); ?><br>
            <strong>TOTAL GENERAL:</strong> Bs. <?php echo e(number_format($totalCredito + $totalContado + $totalPromocion, 2, ',', '.')); ?>

        </div>
    </div>

    <!-- Tabla Crédito -->
    <h5 class="mt-4">VENTAS CRÉDITO</h5>
    <table class="table table-bordered table-sm">
        <thead class="table-secondary">
            <tr>
                <th class="text-start" style="white-space: nowrap; width: 1%;">NOTA DE REMISIÓN</th>
                <th class="text-start">CLIENTE</th>
                <th class="text-start">PRODUCTO</th>
                <th class="text-end">CANTIDAD</th>
                <th class="text-end">MONTO</th>
                <th class="text-start">ESTADO</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ventasCredito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-start" style="white-space: nowrap;"><?php echo e($detalle->preventa->numero_pedido); ?></td>
                <td class="text-start">
                    <?php echo e($detalle->preventa->cliente->nombre_comercio ?? '-'); ?><br>
                    <small class="text-muted"><?php echo e($detalle->preventa->cliente->nombre_propietario ?? ''); ?></small>
                </td>

                <td class="text-start"><?php echo e($detalle->producto->nombre_producto ?? 'Sin nombre'); ?></td>
                <td class="text-end"><?php echo e($detalle->cantidad); ?></td>
                <td class="text-end"><?php echo e(number_format($detalle->subtotal, 2, ',', '.')); ?></td>
                <td class="text-start"><?php echo e($detalle->preventa->cargo->estado ?? 'Sin estado'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">Sin resultados</td>
            </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="4"></th>
                <th class="text-end">Bs. <?php echo e(number_format($totalCredito, 2, ',', '.')); ?></th>
                <th></th>
            </tr>
        </tfoot>
    </table>


    <!-- Tabla Contado -->
    <h5 class="mt-5">VENTAS CONTADO</h5>
    <table class="table table-bordered table-sm">
        <thead class="table-secondary">
            <tr>
                <th class="text-start" style="white-space: nowrap; width: 1%;">NOTA DE REMISIÓN</th>
                <th class="text-start">CLIENTE</th>
                <th class="text-start">PRODUCTO</th>
                <th class="text-end">CANTIDAD</th>
                <th class="text-end">MONTO</th>
                <th class="text-start">ESTADO</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ventasContado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-start" style="white-space: nowrap;"><?php echo e($detalle->preventa->numero_pedido); ?></td>
                <td class="text-start">
                    <?php echo e($detalle->preventa->cliente->nombre_comercio ?? '-'); ?><br>
                    <small class="text-muted"><?php echo e($detalle->preventa->cliente->nombre_propietario ?? ''); ?></small>
                </td>
                <td class="text-start"><?php echo e($detalle->producto->nombre_producto ?? 'Sin nombre'); ?></td>
                <td class="text-end"><?php echo e($detalle->cantidad); ?></td>
                <td class="text-end"><?php echo e(number_format($detalle->subtotal, 2, ',', '.')); ?></td>
                <td class="text-start">Pagado</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">Sin resultados</td>
            </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="4"></th>
                <th class="text-end">Bs. <?php echo e(number_format($totalContado, 2, ',', '.')); ?></th>
                <th></th>
            </tr>
        </tfoot>
    </table>



    <!-- Tabla Promoción -->
    <h5 class="mt-5">VENTAS PROMOCIÓN</h5>
    <table class="table table-bordered table-sm">
        <thead class="table-secondary">
            <tr>
                <th class="text-start" style="white-space: nowrap; width: 1%;">NOTA DE REMISIÓN</th>
                <th class="text-start">CLIENTE</th>
                <th class="text-start">PRODUCTO</th>
                <th class="text-end">CANTIDAD</th>
                <th class="text-end">MONTO</th>
                <th class="text-start">ESTADO</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ventasPromocion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-start" style="white-space: nowrap;"><?php echo e($detalle->preventa->numero_pedido); ?></td>
                <td class="text-start">
                    <?php echo e($detalle->preventa->cliente->nombre_comercio ?? '-'); ?><br>
                    <small class="text-muted"><?php echo e($detalle->preventa->cliente->nombre_propietario ?? ''); ?></small>
                </td>
                <td class="text-start"><?php echo e($detalle->producto->nombre_producto ?? 'Sin nombre'); ?></td>
                <td class="text-end"><?php echo e($detalle->cantidad); ?></td>
                <td class="text-end"><?php echo e(number_format($detalle->subtotal, 2, ',', '.')); ?></td>
                <td class="text-start">Pagado</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">Sin resultados</td>
            </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="4"></th>
                <th class="text-end">Bs. <?php echo e(number_format($totalPromocion, 2, ',', '.')); ?></th>
                <th></th>
            </tr>
        </tfoot>
    </table>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proalpaz\resources\views/reportes/ventas/index.blade.php ENDPATH**/ ?>