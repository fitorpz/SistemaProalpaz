

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center">Reporte de Ingresos</h2>
    <form method="GET" action="<?php echo e(route('reportes.ingresos')); ?>" class="mb-4">
        <div class="row">
            <div class="col-md-4">
                <input type="text" name="nombre_producto" class="form-control" placeholder="Nombre del Producto..." value="<?php echo e(request('nombre_producto')); ?>">
            </div>
            <div class="col-md-3">
                <input type="text" name="codigo_producto" class="form-control" placeholder="Código del Producto..." value="<?php echo e(request('codigo_producto')); ?>">
            </div>
            <div class="col-md-3">
                <select name="tipo_ingreso" class="form-control">
                    <option value="">-- Tipo de Ingreso --</option>
                    <option value="compra" <?php echo e(request('tipo_ingreso') == 'compra' ? 'selected' : ''); ?>>Compra</option>
                    <option value="produccion" <?php echo e(request('tipo_ingreso') == 'produccion' ? 'selected' : ''); ?>>Producción</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Filtrar</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Cantidad</th>
                <th>Fecha Vencimiento</th>
                <th>Tipo</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ingresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ingreso->id); ?></td>
                <td><?php echo e($ingreso->codigo_producto); ?></td>
                <td><?php echo e($ingreso->nombre_producto); ?></td>
                <td><?php echo e($ingreso->cantidad); ?></td>
                <td><?php echo e($ingreso->fecha_vencimiento ?? 'N/A'); ?></td>
                <td><?php echo e(ucfirst($ingreso->tipo_ingreso)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <a href="<?php echo e(route('reportes.ingresos.pdf', request()->all())); ?>" class="btn btn-danger">Generar PDF</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proalpaz3\resources\views/reportes/ingresos.blade.php ENDPATH**/ ?>