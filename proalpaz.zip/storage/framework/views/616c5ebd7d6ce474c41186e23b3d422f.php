
<?php if($formType === 'create'): ?>
<p class="text-muted">El código del cliente se generará automáticamente.</p>


<div class="form-group mb-3">
    <label for="nombre_propietario">Nombre Propietario</label>
    <input type="text" class="form-control" name="nombre_propietario" id="nombre_propietario" value="<?php echo e(old('nombre_propietario')); ?>" required>
</div>

<div class="form-group mb-3">
    <label for="nombre_comercio">Nombre Comercio</label>
    <input type="text" class="form-control" name="nombre_comercio" id="nombre_comercio" value="<?php echo e(old('nombre_comercio')); ?>" required>
</div>

<div class="form-group mb-3">
    <label for="nit">NIT</label>
    <input type="number" class="form-control" name="nit" id="nit" value="<?php echo e(old('nit')); ?>">
</div>

<div class="form-group mb-3">
    <label for="direccion">Dirección</label>
    <input type="text" class="form-control" name="direccion" id="direccion" value="<?php echo e(old('direccion')); ?>">
</div>

<div class="form-group mb-3">
    <label for="referencia">Referencia</label>
    <input type="text" class="form-control" name="referencia" id="referencia" value="<?php echo e(old('referencia')); ?>">
</div>

<div class="form-group mb-3">
    <label for="ubicacion">Ubicación</label>
    <div class="input-group">
        <input type="text" class="form-control" name="ubicacion" id="ubicacion" value="<?php echo e(old('ubicacion')); ?>" required>
        <button type="button" class="btn btn-outline-secondary" onclick="setLocation()">Usar Mi Ubicación</button>
    </div>
</div>

<div class="form-group mb-3">
    <label for="horario_atencion">Horario de Atención</label>
    <input type="text" class="form-control" name="horario_atencion" id="horario_atencion" value="<?php echo e(old('horario_atencion')); ?>">
</div>

<div class="form-group mb-3">
    <label for="telefono">Teléfono</label>
    <input type="text" class="form-control" name="telefono" id="telefono" value="<?php echo e(old('telefono')); ?>">
</div>

<div class="form-group mb-3">
    <label for="cumpleanos_doctor">Cumpleaños del Doctor</label>
    <input type="date" class="form-control" name="cumpleanos_doctor" id="cumpleanos_doctor" value="<?php echo e(old('cumpleanos_doctor')); ?>">
</div>

<div class="form-group mb-3">
    <label for="horario_visita">Horario de Visita</label>
    <input type="text" class="form-control" name="horario_visita" id="horario_visita" value="<?php echo e(old('horario_visita')); ?>">
</div>

<div class="form-group mb-3">
    <label for="observaciones">Observaciones</label>
    <textarea class="form-control" name="observaciones" id="observaciones" rows="3"><?php echo e(old('observaciones')); ?></textarea>
</div>


<div class="form-group mb-3">
    <label for="dia_visita_create">Días de Visita (Máximo 2)</label>
    <div>
        <?php
        $diasSemana = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
        ?>

        <?php $__currentLoopData = $diasSemana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check form-check-inline">
            <input class="form-check-input dia-visita-checkbox-create" type="checkbox" name="dia_visita[]" value="<?php echo e($dia); ?>" id="dia_create_<?php echo e($dia); ?>">
            <label class="form-check-label" for="dia_create_<?php echo e($dia); ?>"><?php echo e($dia); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <small class="text-danger" id="dia_visita_error_create" style="display: none;">Solo puedes seleccionar hasta 2 días.</small>
</div>
<?php endif; ?>


<?php if($formType === 'edit'): ?>
<div class="form-group mb-3">
    <label for="codigo_cliente">Código Cliente</label>
    <input type="text" class="form-control" name="codigo_cliente" id="codigo_cliente" value="<?php echo e($cliente->codigo_cliente ?? old('codigo_cliente')); ?>" readonly>
</div>

<div class="form-group mb-3">
    <label for="nombre_propietario">Nombre Propietario</label>
    <input type="text" class="form-control" name="nombre_propietario" id="nombre_propietario" value="<?php echo e($cliente->nombre_propietario ?? old('nombre_propietario')); ?>" required>
</div>

<div class="form-group mb-3">
    <label for="nombre_comercio">Nombre Comercio</label>
    <input type="text" class="form-control" name="nombre_comercio" id="nombre_comercio" value="<?php echo e($cliente->nombre_comercio ?? old('nombre_comercio')); ?>" required>
</div>

<div class="form-group mb-3">
    <label for="nit">NIT</label>
    <input type="text" class="form-control" name="nit" id="nit" value="<?php echo e($cliente->nit ?? old('nit')); ?>">
</div>

<div class="form-group mb-3">
    <label for="direccion">Dirección</label>
    <input type="text" class="form-control" name="direccion" id="direccion" value="<?php echo e($cliente->direccion ?? old('direccion')); ?>">
</div>

<div class="form-group mb-3">
    <label for="referencia">Referencia</label>
    <input type="text" class="form-control" name="referencia" id="referencia" value="<?php echo e($cliente->referencia ?? old('referencia')); ?>">
</div>

<div class="form-group mb-3">
    <label for="ubicacion">Ubicación</label>
    <div class="input-group">
        <input type="text" class="form-control" name="ubicacion" id="ubicacion" value="<?php echo e($cliente->ubicacion ?? old('ubicacion')); ?>" required>
        <button type="button" class="btn btn-outline-secondary" onclick="setLocation()">Usar Mi Ubicación</button>
    </div>
</div>

<div class="form-group mb-3">
    <label for="horario_atencion">Horario de Atención</label>
    <input type="text" class="form-control" name="horario_atencion" id="horario_atencion" value="<?php echo e($cliente->horario_atencion ?? old('horario_atencion')); ?>">
</div>

<div class="form-group mb-3">
    <label for="telefono">Teléfono</label>
    <input type="text" class="form-control" name="telefono" id="telefono" value="<?php echo e($cliente->telefono ?? old('telefono')); ?>">
</div>

<div class="form-group mb-3">
    <label for="cumpleanos_doctor">Cumpleaños del Doctor</label>
    <input type="date" class="form-control" name="cumpleanos_doctor" id="cumpleanos_doctor" value="<?php echo e($cliente->cumpleanos_doctor ?? old('cumpleanos_doctor')); ?>">
</div>

<div class="form-group mb-3">
    <label for="horario_visita">Horario de Visita</label>
    <input type="text" class="form-control" name="horario_visita" id="horario_visita" value="<?php echo e($cliente->horario_visita ?? old('horario_visita')); ?>">
</div>

<div class="form-group mb-3">
    <label for="observaciones">Observaciones</label>
    <textarea class="form-control" name="observaciones" id="observaciones" rows="3"><?php echo e($cliente->observaciones ?? old('observaciones')); ?></textarea>
</div>

<input type="hidden" name="dia_visita_hidden" value="<?php echo e($cliente->dia_visita); ?>">


<div class="form-group mb-3">
    <label for="dia_visita_edit">Días de Visita (Máximo 2)</label>
    <div>
        <?php
        $diasSemana = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
        $diasSeleccionados = isset($cliente) && !empty($cliente->dia_visita) ? array_map('trim', explode(',', $cliente->dia_visita)) : [];
        ?>

        <?php $__currentLoopData = $diasSemana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check form-check-inline">
            <input
                class="form-check-input dia-visita-checkbox-edit"
                type="checkbox"
                name="dia_visita[]"
                value="<?php echo e($dia); ?>"
                id="dia_edit_<?php echo e($dia); ?>"
                data-dia="<?php echo e($dia); ?>">
            <label class="form-check-label" for="dia_edit_<?php echo e($dia); ?>"><?php echo e($dia); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <small class="text-danger" id="dia_visita_error_edit" style="display: none;">Solo puedes seleccionar hasta 2 días.</small>
</div>



<?php endif; ?><?php /**PATH C:\xampp\htdocs\proalpaz3\resources\views/clientes/partials/form.blade.php ENDPATH**/ ?>