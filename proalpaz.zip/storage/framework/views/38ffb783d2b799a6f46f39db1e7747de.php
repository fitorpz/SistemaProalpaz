<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Rutas Programadas</title>
    <style>
        body { font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .text-center { text-align: center; }
        .badge-success { color: green; font-weight: bold; }
        .badge-danger { color: red; font-weight: bold; }
    </style>
</head>
<body>

    <h2 class="text-center">Reporte de Rutas Programadas</h2>
    <p><strong>Fecha Generación:</strong> <?php echo e(now()->format('d/m/Y H:i:s')); ?></p>

    <table>
        <tr>
            <th>Filtro</th>
            <th>Valor</th>
        </tr>
        <tr>
            <td>Fecha</td>
            <td><?php echo e($filtros['Fecha']); ?></td>
        </tr>
        <tr>
            <td>Usuario</td>
            <td><?php echo e($filtros['Usuario']); ?></td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th>Cliente</th>
                <th>Dirección</th>
                <th>Estado</th>
                <th>Ubicación</th>
                <th>Observaciones</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cliente->nombre_comercio); ?> - <?php echo e($cliente->nombre_propietario); ?></td>
                <td><?php echo e($cliente->direccion); ?></td>
                <td class="text-center">
                    <?php if($cliente->visitas->isNotEmpty()): ?>
                        <span class="badge-success">✔ Registrada</span>
                    <?php else: ?>
                        <span class="badge-danger">✘ No Registrada</span>
                    <?php endif; ?>
                </td>
                <td class="text-center">
                    <?php if($cliente->visitas->isNotEmpty() && $cliente->visitas->first()->ubicacion): ?>
                        <a href="<?php echo e($cliente->visitas->first()->ubicacion); ?>" target="_blank">Ver Ubicación</a>
                    <?php else: ?>
                        No disponible
                    <?php endif; ?>
                </td>
                <td><?php echo e($cliente->visitas->first()->observaciones ?? 'Sin observaciones'); ?></td>
                <td class="text-center">
                    <?php if($cliente->visitas->isEmpty()): ?>
                        <span class="badge-danger">No registrada</span>
                    <?php else: ?>
                        <span class="badge-success"><?php echo e($cliente->visitas->first()->created_at->format('H:i')); ?></span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\proalpaz3\resources\views/rutas/pdf_reporte.blade.php ENDPATH**/ ?>