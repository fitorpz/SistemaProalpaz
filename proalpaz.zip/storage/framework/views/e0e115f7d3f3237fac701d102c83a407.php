<?php

use Carbon\Carbon;

$fechaGeneracion = Carbon::now()->format('d/m/Y H:i:s');
function numberToWords($number)
{
    if (!class_exists('NumberFormatter')) {
        return 'Extensión intl no habilitada.';
    }

    $parts = explode('.', number_format($number, 2, '.', ''));
    $whole = $parts[0];
    $fraction = $parts[1] ?? '00';

    $formatter = new \NumberFormatter('es', \NumberFormatter::SPELLOUT);
    $literal = $formatter->format($whole);

    return ucfirst($literal) . ' con ' . $fraction . '/100';
}
$logoPath = public_path('logoHeader.png');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Ventas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #000;
            padding: 4px;
        }

        .text-start {
            text-align: left;
        }

        .text-end {
            text-align: right;
        }

        .title {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .section-title {
            background: #eee;
            font-weight: bold;
            padding: 5px;
        }
    </style>
</head>
<body>
    <table style="width: 100%; margin-bottom: 20px; border: none;">
        <tr>
            <td style="width: 50%; text-align: left; vertical-align: top; border: none;">
                <img src="<?php echo e($logoPath); ?>" alt="Logo de la empresa" style="width: 180px; height: auto;">
                <p><strong>Generado el:</strong> <?php echo e($fechaGeneracion); ?></p>
            </td>
            <td style="width: 50%; text-align: right; vertical-align: top; border: none;">
                <strong>PREVENTISTA:</strong> <?php echo e($usuario->nombre ?? 'Todos'); ?><br>
                <strong>DEL:</strong> <?php echo e($request->del ?? '---'); ?><br>
                <strong>AL:</strong> <?php echo e($request->al ?? '---'); ?><br>
                <strong>TOTAL CRÉDITO:</strong> Bs. <?php echo e(number_format($totalCredito, 2, ',', '.')); ?><br>
                <strong>TOTAL CONTADO:</strong> Bs. <?php echo e(number_format($totalContado, 2, ',', '.')); ?><br>
                <strong>TOTAL PROMOCIÓN:</strong> Bs. <?php echo e(number_format($totalPromocion, 2, ',', '.')); ?><br>
                <strong>TOTAL GENERAL:</strong> Bs. <?php echo e(number_format($totalCredito + $totalContado + $totalPromocion, 2, ',', '.')); ?>

            </td>
        </tr>
    </table>
    <div class="title">REPORTE DE VENTAS</div>

    
    <p class="section-title">VENTAS CRÉDITO</p>
    <table>
        <thead>
            <tr>
                <th class="text-start">NOTA REMISIÓN</th>
                <th class="text-start">CLIENTE</th>
                <th class="text-start">PRODUCTO</th>
                <th class="text-end">CANTIDAD</th>
                <th class="text-end">MONTO</th>
                <th class="text-start">ESTADO</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ventasCredito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-start" style="white-space: nowrap;"><?php echo e($item->preventa->numero_pedido); ?></td>
                <td class="text-start">
                    <?php echo e($item->preventa->cliente->nombre_comercio ?? '-'); ?><br>
                    <small><?php echo e($item->preventa->cliente->nombre_propietario ?? ''); ?></small>
                </td>
                <td class="text-start"><?php echo e($item->producto->nombre_producto ?? '-'); ?></td>
                <td class="text-end"><?php echo e($item->cantidad); ?></td>
                <td class="text-end"><?php echo e(number_format($item->subtotal, 2, ',', '.')); ?></td>
                <td class="text-start"><?php echo e($item->preventa->cargo->estado ?? 'Sin estado'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-start">Sin resultados</td></tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr><th colspan="4"></th><th class="text-end">Bs. <?php echo e(number_format($totalCredito, 2, ',', '.')); ?></th><th></th></tr>
        </tfoot>
    </table>

    
    <p class="section-title">VENTAS CONTADO</p>
    <table>
        <thead>
            <tr>
                <th class="text-start">NOTA REMISIÓN</th>
                <th class="text-start">CLIENTE</th>
                <th class="text-start">PRODUCTO</th>
                <th class="text-end">CANTIDAD</th>
                <th class="text-end">MONTO</th>
                <th class="text-start">ESTADO</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ventasContado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-start"><?php echo e($item->preventa->numero_pedido); ?></td>
                <td class="text-start">
                    <?php echo e($item->preventa->cliente->nombre_comercio ?? '-'); ?><br>
                    <small><?php echo e($item->preventa->cliente->nombre_propietario ?? ''); ?></small>
                </td>
                <td class="text-start"><?php echo e($item->producto->nombre_producto ?? '-'); ?></td>
                <td class="text-end"><?php echo e($item->cantidad); ?></td>
                <td class="text-end"><?php echo e(number_format($item->subtotal, 2, ',', '.')); ?></td>
                <td class="text-start">Pagado</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-start">Sin resultados</td></tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr><th colspan="4"></th><th class="text-end">Bs. <?php echo e(number_format($totalContado, 2, ',', '.')); ?></th><th></th></tr>
        </tfoot>
    </table>

    
    <p class="section-title">VENTAS PROMOCIÓN</p>
    <table>
        <thead>
            <tr>
                <th class="text-start">NOTA REMISIÓN</th>
                <th class="text-start">CLIENTE</th>
                <th class="text-start">PRODUCTO</th>
                <th class="text-end">CANTIDAD</th>
                <th class="text-end">MONTO</th>
                <th class="text-start">ESTADO</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ventasPromocion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-start"><?php echo e($item->preventa->numero_pedido); ?></td>
                <td class="text-start">
                    <?php echo e($item->preventa->cliente->nombre_comercio ?? '-'); ?><br>
                    <small><?php echo e($item->preventa->cliente->nombre_propietario ?? ''); ?></small>
                </td>
                <td class="text-start"><?php echo e($item->producto->nombre_producto ?? '-'); ?></td>
                <td class="text-end"><?php echo e($item->cantidad); ?></td>
                <td class="text-end"><?php echo e(number_format($item->subtotal, 2, ',', '.')); ?></td>
                <td class="text-start">Pagado</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-start">Sin resultados</td></tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr><th colspan="4"></th><th class="text-end">Bs. <?php echo e(number_format($totalPromocion, 2, ',', '.')); ?></th><th></th></tr>
        </tfoot>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\proalpaz\resources\views/reportes/pdf/ventas.blade.php ENDPATH**/ ?>